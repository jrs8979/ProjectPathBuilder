package Players.jrs8979;

import Interface.Coordinate;
import Interface.PlayerModulePart1;
import Interface.PlayerMove;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Created by JScidaDesktop on 03/21/17.
 */
public class jrs8979 implements PlayerModulePart1{
    private int[][] board;
    private int playerId;
    private int dimention;

    /* Initializes player and board, using helper method ot make the board */
    @Override
    public void initPlayer(int dim, int playerId){
        this.playerId = playerId;
        dimention = dim * 2 + 1;
        board = new int[dimention][dimention];
        initBoard(board);
    }

    /* Helper method to create the game board */
    private void initBoard(int[][] board){
        for(int i = 0; i < dimention; i++){
            for(int j = 0; j < dimention; j++){
                if(i % 2 == 0){
                    if(j % 2 == 1){
                        board[i][j] = 2;
                    }
                } else {
                    if(j % 2 == 0){
                        board[i][j] = 1;
                    }
                }
            }
        }
    }

    /* Places the last move on the board */
    @Override
    public void lastMove(PlayerMove m){
        Coordinate move = m.getCoordinate();
        int x = move.getRow();
        int y = move.getCol();
        int id = m.getPlayerId();
        board[x][y] = id;
    }

    /* Dont know what it does */
    @Override
    public void otherPlayerInvalidated(){}

    /* Gives the move for the player to use, not valid for player configs */
    @Override
    public PlayerMove move() { return null; }

    /* Parses through the board and detects which player won the game */
    @Override
    public boolean hasWonGame(int id){
        ArrayList<Coordinate> queue = new ArrayList<>();
        HashSet<Coordinate> visited = new HashSet<>();
        if(id == 1){
            for(int i = 1; i < dimention; i = i + 2){
                Coordinate add = new Coordinate(i, 0);
                queue.add(add);
            }
        } else {
            for(int i = 1; i < dimention; i = i + 2){
                Coordinate add = new Coordinate(0, i);
                queue.add(add);
            }
        }

        for (int row = 0; row < dimention; row++) {
            for (int col = 0; col < dimention; col++) {
                System.out.print(board[row][col] + "  ");
            }
            System.out.print("\n");
        }
        System.out.println("\n");

        while(!queue.isEmpty()){
            Coordinate currCoordiante = queue.get(0);
            int col = currCoordiante.getCol();
            int row = currCoordiante.getRow();
            if(col == dimention - 1 || row == dimention - 1){
                return true;
            } else {
                if(!(row + 1 > dimention - 1) && board[row + 1][col] == id){
                    Coordinate front = new Coordinate(row + 1, col);
                    if(!queue.contains(front) && !visited.contains(front)){
                        queue.add(front);
                    }
                }
                if(!(col + 1 > dimention - 1) && board[row][col + 1] == id){
                    Coordinate bottom = new Coordinate(row, col + 1);
                    if(!queue.contains(bottom) && !visited.contains(bottom)){
                        queue.add(bottom);
                    }
                }
                if(!(row - 1 < 1) && board[row - 1][col] == id){
                    Coordinate back = new Coordinate(row - 1, col);
                    if(!queue.contains(back) && !visited.contains(back)){
                        queue.add(back);
                    }
                }
                if(!(col - 1 < 1) && board[row][col - 1] == id){
                    Coordinate top = new Coordinate(row, col - 1);
                    if(!queue.contains(top) && !visited.contains(top)){
                        queue.add(top);
                    }
                }
                queue.remove(currCoordiante);
                visited.add(currCoordiante);
            }
        }
        return false;
    }
}
